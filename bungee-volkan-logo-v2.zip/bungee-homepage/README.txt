BUNGEE PRO - CLEANED HOMEPAGE

Bu paket, paylastigin Webflow sayfa kaynagindaki Markdown kacislarindan temizlenerek gercek HTML'e donusturuldu.

- index.html: temizlenmis ana sayfa
- routes.txt: kaynakta bulunan diger site yollari

CSS, JavaScript, gorseller ve videolar su anda orijinal Webflow/CDN adreslerinden yuklenir; internet baglantisi gerekir.
Diger sayfalarin HTML kaynaklari bu tek kaynakta bulunmadigi icin ZIP ana sayfayi icerir.
Webflow CMS/form gibi sunucu tarafli ozellikler baska hostta ayrica uyarlanmalidir.
Tema ve medya icin gecerli lisans/telif kosullarina uyun.
